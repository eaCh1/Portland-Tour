﻿http://romannurik.github.io/AndroidAssetStudio/nine-patches.html


http://stackoverflow.com/questions/29294287/android-studio-drawable-folder-how-to-put-images-for-multiple-dpi